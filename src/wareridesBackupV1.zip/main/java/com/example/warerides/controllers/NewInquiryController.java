package com.example.warerides.controllers;

public class NewInquiryController {
}
