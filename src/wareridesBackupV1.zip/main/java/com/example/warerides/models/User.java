package com.example.warerides.models;

public class User {
    private int userId;
    private String userName;
    private String userPassword;
    private String branchId;


}

